#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>

static void resize(int width, int height){

glViewport(0, 0, width, height);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho (-6.4,6.4,-4.8,4.8, 10.0, -10.0);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
}

static void display(void){

glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glColor3d(1,0,0);

// Define a cor de fundo da janela de visualização como branca
glClearColor(0.0f, 0.0f, 0.0f, 0.0f);



// Habilita a definição da cor do material a partir da cor corrente
glEnable(GL_COLOR_MATERIAL);

//Habilita o uso de iluminação
glEnable(GL_LIGHTING);  

// Habilita a luz de número 0
glEnable(GL_LIGHT0);

// Habilita o depth-buffering
glEnable(GL_DEPTH_TEST);



// cor
glShadeModel(GL_SMOOTH);
GLfloat luzAmbiente[4]={0.2,0.2,0.2,1.0}; 

GLfloat luzDifusa[4]={0.7,0.7,0.7,1.0};          

GLfloat luzEspecular[4]={1.0, 1.0, 1.0, 1.0}; 

GLfloat posicaoLuz[4]={0.0, 50.0, -50.0, 1.0};



// Capacidade de brilho do material
GLfloat especularidade[4]={1.0,1.0,1.0,1.0}; 
GLint especMaterial = 60;



// Define a refletância do material 
glMaterialfv(GL_FRONT,GL_SPECULAR, especularidade);

// Define a concentração do brilho
glMateriali(GL_FRONT,GL_SHININESS,especMaterial);



// Ativa o uso da luz ambiente 
glLightModelfv(GL_LIGHT_MODEL_AMBIENT, luzAmbiente);



// Define os parâmetros da luz de número 0
glLightfv(GL_LIGHT0, GL_AMBIENT, luzAmbiente); 
glLightfv(GL_LIGHT0, GL_DIFFUSE, luzDifusa );
glLightfv(GL_LIGHT0, GL_SPECULAR, luzEspecular );
glLightfv(GL_LIGHT0, GL_POSITION, posicaoLuz );   

glBegin(GL_POLYGON);
glColor3f(0.0,1.0,0.0);
glNormal3f(-1,0,0);

glVertex3f(-15.0,-15.0,3.0);
glVertex3f(-15.0,15.0,3.0);
glVertex3f(15.0,15.0,3.0);
glVertex3f(15.0,-15.0,3.0);
glEnd();

//peito
glPushMatrix();
glTranslatef(0,0,0);
glColor3f(1.0,1.0,0.0);
glutSolidSphere(1.5,100,100);
glPopMatrix();

//cabeca
glPushMatrix();
glTranslatef (0,2.,0);
glColor3f(1.0,1,1);
glutSolidSphere(1,20,20);
glPopMatrix();

//OLHO ESQUERDO
glPushMatrix();
glTranslatef (-0.4,2.3,-1.5);
glColor3f(0.0,0,1);
glutSolidSphere(0.2,20,20);
glPopMatrix();

//OLHO DIREITO
glPushMatrix();
glTranslatef (0.4,2.3,-1.5);
glColor3f(0.0,0,1);
glutSolidSphere(0.2,20,20);
glPopMatrix();

//BARRIGA
glPushMatrix();
glTranslatef (0,-3,0);
glColor3f(1.0,1,1);
glutSolidSphere(2,20,20);
glPopMatrix();


glutSwapBuffers();

}


void Controle(int key, int x, int y) {
  switch (key) {
    case GLUT_KEY_UP :                 
      glRotatef(-1.0, 1.0, 0.0, 0.0); 
    break;

    case GLUT_KEY_DOWN :
      glRotatef(1.0, 1.0, 0.0, 0.0);
    break;

    case GLUT_KEY_LEFT :                
      glRotatef(-1.0, 0.0, 1.0, 0.0);
    break;

    case GLUT_KEY_RIGHT :
      glRotatef(1.0, 0.0, 1.0, 0.0);
    break;
  }
  glutPostRedisplay();
}

int main(int argc, char *argv[])
{
glutInit(&argc, argv);
glutInitWindowSize(640,480);
glutInitWindowPosition(10,10);
glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

glutCreateWindow("Snow Man OpenGL de Borracha");

glutReshapeFunc(resize);
glutDisplayFunc(display);
glutSpecialFunc(Controle);

glClearColor(0,0,0,0);

glEnable(GL_DEPTH_TEST);

glutMainLoop();

return
EXIT_SUCCESS;
} 
