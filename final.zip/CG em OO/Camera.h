#include "Vector3.h"

using namespace std;

void Mundo_Camera(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp , Vector3 &ponto);
void Camera_Mundo(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp , Vector3 &ponto);
void Transl(Vector3 delta , Vector3 &ponto);
void Esc(Vector3 delta , Vector3 &ponto);
void Rot(double angle, char axis , Vector3 &ponto);