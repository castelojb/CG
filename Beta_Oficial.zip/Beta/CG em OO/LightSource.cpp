/*
 * LightSource.cpp
 *
 *  Created on: 26 de set de 2018
 *      Author: joao
 */

#include "LightSource.h"

Light_Source::Light_Source(Vector3 position,Vector3 color) {
	// TODO Auto-generated constructor stub
	this->position=position;
	this->color=color;
}

