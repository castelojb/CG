#include "Sphere.h"
#include <math.h>
#include "LightSource.h" 
#include "Iluminacao.h"
#include "Camera.h"
Sphere::Sphere(Vector3 centro , double raio , Texture textura){
	this->centro=centro;
	this->raio=raio;
	this->textura=textura;
}
Sphere::Sphere(){
        this->centro={0,0,0};
        this->raio=0.0f;
        this->textura=Texture({0,0,0},{0,0,0},{0,0,0});
}
bool Sphere::RayIntersects(Vector3 raydir , float *icaro)
{
        Vector3 aux={0,0,0};
float a = raydir.Dot(raydir);
float b = raydir .Dot( ( ( raydir - this->centro)))*2.0f;
float c = this->centro.Dot(this->centro) + raydir.Dot(raydir) -2.0f*raydir.Dot(this->centro) - this->raio*this->raio;

//float b = 2 * dot(transformedRay.direction, transformedRay.origin);
//float b=2* raydir.Dot(aux);
//float c = transformedRay.origin.lengthSquared() - (radius * radius);
//float c= aux.Dot(aux) - this->raio*this->raio;

float D = b*b + (-4.0f)*a*c;

// If ray can not intersect then stop
if (D < 0)
        return false;
D=sqrtf(D);

// Ray can intersect the sphere, solve the closer hitpoint
float t = (-0.5f)*(b+D)/a;
if (t >= 0.0f){   
        *icaro=t;

        }
else
        return false;

return true;
}

Vector3 Sphere::getNormal(Vector3 hitpoint){
        return (hitpoint - this->centro) / this->raio;
}

Texture Sphere::getTexture(){
        return this->textura;
}

void Sphere::Transform_Camera_Mundo(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp){
        Camera_Mundo(camera , LoockAt , ViewUp , this->centro);
}
void Sphere::Transform_Mundo_Camera(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp){
        Mundo_Camera(camera ,LoockAt ,ViewUp , this->centro);
}