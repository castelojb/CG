/*
 * Main.cpp
 *
 *  Created on: 21 de set de 2018
 *      Author: joao
 */

//includes do c++
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <fstream>
#include <string>
#include <math.h>
#include <vector>

//include da imagem
#include "CImg.h"

//includes do GL
#include <GL/glew.h>
#include <GL/glut.h>
# include <GL/freeglut.h>

//arquivos usados
#include "Vector3.h"
#include "LightSource.h"
#include "Sphere.h"
#include "Iluminacao.h"
#include "Camera.h"
#include "Plano.h"
//#include "ImageClass.h"
//#include "SOIL.h"



using namespace std;

string nome="direita.jpeg";;


//dimensoes da tela, adaptar com a quantidade de pixels da imagem usada
GLdouble windowWidth  = 500.0;
GLdouble windowHeight = 500.0;

int window;
Vector3 camera={0,0,-250};;
//CImg fundo;

GLuint* vao;
GLuint* vbo;
GLuint* ibo;


void Desenho(void)
{

	cout<<"Fazendo imagem"<<endl;

	using namespace cimg_library;

	//limpando a tela
	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_POINTS);
	

	//pintando o fundo
	CImg<unsigned char> fundo(nome.data());

	for(int i = 0; i < windowWidth; ++i){
		for(int j = 0; j < windowHeight; ++j){
			
			//x e y
			double x = (i  - windowWidth/2);
			double y = (j - windowHeight/2);
			Vector3 Ipix;
			Ipix[0] = (double)fundo(i, windowHeight-j, 0, 0)/255;
			Ipix[1] = (double)fundo(i, windowHeight-j, 0, 1)/255;
			Ipix[2] = (double)fundo(i, windowHeight-j, 0, 2)/255;
			glColor3f(Ipix[0], Ipix[1], Ipix[2]);
			glVertex2f(x, y);
		}
	}

	//definindo o boneco
	Sphere Snow_Man[9];

		Sphere barriga=Sphere({0.0f,-96.0f,300.0f}, 160.0f , Texture({0.5f,0.5f,0.5f} , {0.3f,0.3f,0.3f} , {0.3f,0.3f,0.3f}));
	
		Sphere cabeca=Sphere({0.0f,150.0f,300.0f}, 100.0f , Texture({0.5f,0.5f,0.5f} , {0.3f,0.3f,0.3f} , {0.3f,0.3f,0.3f}));
	
		Sphere olho_direito=Sphere({-20.0f,150.0f,200.0f}, 8.0f , Texture({0.2f,0.2f,0.2f} , {0.2f,0.2f,0.2f} , {0.2f,0.2f,0.2f}));
	
		Sphere olho_esquerdo=Sphere({20.0f,150.0f,200.0f}, 8.0f , Texture({0.2f,0.2f,0.2f} , {0.2f,0.2f,0.2f} , {0.2f,0.2f,0.2f}));
	
		Sphere nariz=Sphere({0.0f,120.0f,200.0f}, 8.0f , Texture({0.9f,0.2f,0.2f} , {0.9f,0.2f,0.2f} , {0.9f,0.2f,0.2f}));
	
		Sphere b1=Sphere({0.0f,0.0f,170.0f}, 8.0f , Texture({0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f}));
		Sphere b2=Sphere({0.0f,-30.0f,150.0f}, 8.0f , Texture({0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f}));
		Sphere b3=Sphere({0.0f,-60.0f,140.0f}, 6.5f , Texture({0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f}));
		Sphere b4=Sphere({0.0f,-90.0f,137.0f}, 6.0f , Texture({0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f} , {0.2f,0.9f,0.2f}));
		
		Snow_Man[0]=cabeca;
		Snow_Man[1]=barriga;
		Snow_Man[2]=olho_direito;
		Snow_Man[3]=olho_esquerdo;
		Snow_Man[4]=nariz;
		Snow_Man[5]=b1;
		Snow_Man[6]=b2;
		Snow_Man[7]=b3;
		Snow_Man[8]=b4;

	Sphere Snow_Man2[2];
		Sphere barriga2=Sphere({-300.0f,-96.0f,600.0f}, 160.0f , Texture({0.5f,0.5f,0.5f} , {0.3f,0.3f,0.3f} , {0.3f,0.3f,0.3f}));
		Sphere cabeca2=Sphere({-300.0f,150.0f,600.0f}, 100.0f , Texture({0.5f,0.5f,0.5f} , {0.3f,0.3f,0.3f} , {0.3f,0.3f,0.3f}));
		Snow_Man2[0] = barriga2;
		Snow_Man2[1] = cabeca2;
	
	Sphere Snow_Man3[2];
		Sphere barriga3=Sphere({300.0f,-96.0f,600.0f}, 160.0f , Texture({0.5f,0.5f,0.5f} , {0.3f,0.3f,0.3f} , {0.3f,0.3f,0.3f}));
		Sphere cabeca3=Sphere({300.0f,150.0f,600.0f}, 100.0f , Texture({0.5f,0.5f,0.5f} , {0.3f,0.3f,0.3f} , {0.3f,0.3f,0.3f}));
		Snow_Man3[0] = barriga3;
		Snow_Man3[1] = cabeca3;
	
	//Definindo o plano infinito
	Plano chao =Plano({0.0f,-256.0f,300.0f},{0,-256,400},{100,-256,300},Texture({0.75f,0.5f,0.5f} , {0.2f,0.2f,0.2f} , {0.2f,0.2f,0.2f}));
	
	//vetor que guarda elementos do cenario
	vector<Objeto*> cenario;
	
	//Colocando os bonecos no cenario
	for(int k=0;k<9;k++){
		cenario.push_back(&Snow_Man[k]);
	}

	cenario.push_back(&Snow_Man2[0]);
	cenario.push_back(&Snow_Man2[1]);
	cenario.push_back(&Snow_Man3[0]);
	cenario.push_back(&Snow_Man3[1]);
	cenario.push_back(&chao);
	



	//luz ambiente	
    Light_Source sun=Light_Source({30000.0f,30000.0f,00000.0f},{0.9f,0.9f,0.9f});

	//onde esta a camera , para onde olha e a orientaçao
	Vector3 LoockAt={0.0f,-96.0f,300.0f};
	Vector3 ViewUp= {0.0f,150.0f,300.0f};
	
	
	//levando o cenario para o mundo da camera
	for(int k=0; k<cenario.size();k++){
		cenario[k]->Transform_Mundo_Camera(camera , LoockAt , ViewUp);
	}

	
	//levando o sol para o mundo da camera
	Mundo_Camera(camera,LoockAt,ViewUp,sun.position);


	//levando a camera para o seu mundo
	Mundo_Camera(camera,LoockAt,ViewUp,camera);
	

	for(int i = 0; i < windowWidth; ++i)
	{
		for(int j = 0; j < windowHeight; ++j)
		{
			//x e y
			double x = (i  - windowWidth/2);
			double y = (j - windowHeight/2);
			
			//Vetor para armazenar objetos atingidos pelo raio
			vector<Objeto*> objetos_interceptados;

			//Vetor para armazenar as distancias registradas para um raio
			vector<float> distancias;
			
			//variavel que guarda a distancia do raio
			float t;
			
			//vetor de posicionamento da tela (x,y,d)		
			Vector3 point={x,y,150};

			//percorrendo o cenario para saber se o raio intercepta um ponto
			for(int k=0;k<cenario.size();k++){

				if(cenario[k]->RayIntersects( (point - camera),camera ,&t)){
					distancias.push_back(t);
					objetos_interceptados.push_back(cenario[k]);
				}
				
			}

			//se o tamanho do meu vetor eh diferente de 0, alguem foi interceptado
			if(distancias.size() != 0){

				//laco para descobrir a menor distancia para saber o que deve ser exibido
				int menor=0;
				for(int k=0 ; k< distancias.size() ; k++){
					if(distancias[menor]>distancias[k]){
						menor=k;
					}
				}

				//calculo de onde esta localizado o ponto que sera exibido (ponto_da_origem_do_raio + direcao_do_raio * distancia)
				Vector3 hitpoint = camera + (point - camera)*distancias[menor];

				//assume-se que nao tem sombra, de inicio
				bool sombra=false;

				//laco que vai verificar se o raio que sai do hitpoint ate a fonte de luz eh obstruido por algum objeto
				for(int k=0;k<cenario.size();k++){
					if(cenario[k]->RayIntersects((sun.position - hitpoint).Normalize(),hitpoint , &t)){
						sombra=true;
								
					}
				}
				

				if(sombra){					

				
					//calculo da cor da sombra
					Vector3 normal=objetos_interceptados[menor]->getNormal(hitpoint);

	    			Iluminacao rgb=Iluminacao(objetos_interceptados[menor]->getTexture(),sun);

	    			glColor3d(rgb.Ipix[0],rgb.Ipix[1],rgb.Ipix[2]);
	    			
	        
				}else{
					
					//calculo da cor normal
					Vector3 normal=objetos_interceptados[menor]->getNormal(hitpoint);

	    			Iluminacao rgb=Iluminacao(camera , hitpoint , normal , objetos_interceptados[menor]->getTexture() , sun);
	    			
	    			glColor3d(rgb.Ipix[0],rgb.Ipix[1],rgb.Ipix[2]);	
						
				}
				
				glVertex2d(x,y);
			}



		}
	}
	cout<<"Fim"<<endl;

	glEnd();
	glFlush();
	


}


// Callback do GLUT: Chamado na criação da janela e toda vez que ela for redimensionada
void _Redimensionar(int w, int h)
{
	windowWidth = w;
	windowHeight = h;

	// Redefinição do viewport e projeção
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-w/2, w/2, -h/2, h/2);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//glutPostRedisplay();
}

// Callback do GLUT: Eventos de teclado
void _Teclado(unsigned char key, int x, int y)
{
	switch((char)key)
	{
		// ESC
		case 27:
			glutDestroyWindow(window);
			exit(0);
			break;

		case 'w':
			camera={0,0,-250};
			nome="direita.jpeg";

			break;
		case 's':
			camera={0.0f,0.0f,850.0f};
			nome="costa.jpeg";
			break;

		case 'a':
			camera={454,0,0};
			nome="esquerda.jpeg";
			break;
		case 'd':
			camera={-454,0,0};
			nome="frente.jpeg";
			break;
		case 'q':
			camera={0,454,0};
			nome="chao.jpeg";
			break;
		case 'e':
			camera={0,-454,0};
			nome="teto.jpeg";
			break;
	}

	glutPostRedisplay();
}

// Callback do GLUT: Eventos de mouse com algum botão pressionado
void _Mouse(int x, int y)
{

}

int main(int argc, char *argv[])
{
	
	// Inicialização do GLUT e janela
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize((int) windowWidth, (int) windowHeight);
	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)- windowWidth)/2, (glutGet(GLUT_SCREEN_HEIGHT)- windowHeight)/2);
	window = glutCreateWindow("O mar de blood");

	glewExperimental = GL_TRUE;

	// Definição de callbacks
	glutReshapeFunc(_Redimensionar);
	glutKeyboardFunc(_Teclado);
	glutMotionFunc(_Mouse);
	glutDisplayFunc(Desenho);


	glutMainLoop();
	exit(0);
}
