#include "Vector3.h"

using namespace std;

void Mundo_Camera(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp , Vector3 &ponto);
void Camera_Mundo(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp , Vector3 &ponto);