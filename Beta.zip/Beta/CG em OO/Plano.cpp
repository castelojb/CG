#include "Plano.h"
#include "Camera.h"

Plano::Plano(Vector3 position1 ,Vector3 position2,Vector3 position3, Texture textura){
	this->textura=textura;
	this->position1=position1;
	this->position2=position2;
	this->position3=position3;
	
}

Plano::Plano(){
	this->textura=Texture({0,0,0} , {0,0,0} , {0,0,0});
	this->position1={0,0,0};
	this->position2={0,0,0};
	this->position3={0,0,0};	
}


bool Plano::RayIntersects(Vector3 raydir , float *icaro){
	float dDotN = raydir.Dot(this->getNormal({0,0,0}));		//dot(intersection.ray.direction, normal);
	
	//paralelo ao plano = infinitas interseções
	if (dDotN == 0.0f){
		return false;
	}

	//Vector3 posicao={0.0f,-256.0f,300.0f};
	//Vector3 rayorg={0,0,-1};

	float t =(this->position1-raydir).Dot(this->getNormal({0,0,0})) / dDotN; 		//dot({0.0f,-256.0f,300.0f} - intersection.ray.origin, normal) / dDotN;

	//perto demais
	if (t <= -1) {
		return false;
	}
	/*
	//já achei alguém mais próximo
	if (t >= intersection.t){
		return false;
	}
	*/
	*icaro = t;
	//intersection.pShape = this;
	
	return true;
}

Vector3 Plano::getNormal(Vector3 hitpoint){
	Vector3 ray1= (this->position2 - this->position1).Normalize();
	Vector3 ray2=(this->position3 - this->position1).Normalize();

	return ray1.Cross(ray2);

}

Texture Plano::getTexture(){
	return this->textura;
}

void Plano::Transform_Camera_Mundo(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp){
        Camera_Mundo(camera , LoockAt , ViewUp , this->position1);
        Camera_Mundo(camera , LoockAt , ViewUp , this->position2);
        Camera_Mundo(camera , LoockAt , ViewUp , this->position3);
}
void Plano::Transform_Mundo_Camera(Vector3 camera , Vector3 LoockAt , Vector3 ViewUp){
        Mundo_Camera(camera ,LoockAt ,ViewUp , this->position1);
        Mundo_Camera(camera ,LoockAt ,ViewUp , this->position2);
        Mundo_Camera(camera ,LoockAt ,ViewUp , this->position3);
}